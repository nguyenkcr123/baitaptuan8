package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.Random;

public class M000ActSplash extends Activity {

    // Dùng 1 icon có sẵn để tránh thiếu resource
    private final int[] animalIcons = { R.drawable.ic_cat };
    private final int[] bgColors = {
            0xFF303F9F, 0xFF00695C, 0xFF4E342E
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m000_act_splash);

        Random rd = new Random();
        int color = bgColors[rd.nextInt(bgColors.length)];
        int icon  = animalIcons[rd.nextInt(animalIcons.length)];

        View root = findViewById(android.R.id.content);
        root.setBackgroundColor(color);
        ((ImageView) findViewById(R.id.imgAnimal)).setImageResource(icon);

        View overlay = findViewById(R.id.loading);
        overlay.setVisibility(View.VISIBLE);
        overlay.postDelayed(() -> overlay.setVisibility(View.GONE), 2000);
    }
}
